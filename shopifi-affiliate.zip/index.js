// index.js
const express = require('express');
const bodyParser = require('body-parser');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const db = require('./db');
const affiliateService = require('./affiliateService');

const app = express();
app.use(bodyParser.json());

const SHOPIFY_WEBHOOK_SECRET = process.env.SHOPIFY_WEBHOOK_SECRET || 'change_me';

function verifyShopifyWebhook(req) {
  const hmac = req.get('X-Shopify-Hmac-Sha256') || '';
  const body = JSON.stringify(req.body);
  const digest = crypto.createHmac('sha256', SHOPIFY_WEBHOOK_SECRET).update(body).digest('base64');
  try { return crypto.timingSafeEqual(Buffer.from(digest), Buffer.from(hmac)); } catch(e){ return false; }
}

// Beacon/click endpoint
app.post('/affiliate/click', (req, res) => {
  try {
    const token = req.body.token || (typeof req.body === 'string' && JSON.parse(req.body).token);
    if (!token) return res.status(400).send('no token');
    const row = {
      id: uuidv4(),
      affiliate: token,
      url: req.body.url || req.headers.referer || '',
      ip: req.ip,
      user_agent: req.get('user-agent') || '',
      created_at: Date.now()
    };
    db.insertClick(row);
    res.status(200).send('ok');
  } catch (err) {
    console.error(err);
    res.status(500).send('err');
  }
});

// Shopify orders/paid webhook
app.post('/webhooks/orders/paid', (req, res) => {
  if (!verifyShopifyWebhook(req)) {
    console.warn('Invalid HMAC');
    return res.status(401).send('invalid');
  }
  const order = req.body;
  const orderId = order.id || order.order_number || order.name;
  const email = order.email || (order.customer && order.customer.email) || null;
  const amount = parseFloat(order.total_price || order.current_total_price || 0);

  // Try to get affiliate from note_attributes if merchant's theme added it
  let affiliate = null;
  if (order.note_attributes && Array.isArray(order.note_attributes)) {
    const na = order.note_attributes.find(n => n.name === 'affiliate_token' || n.name === 'affiliate');
    if (na) affiliate = na.value;
  }

  const conversion = {
    id: uuidv4(),
    order_id: String(orderId),
    email,
    amount,
    affiliate: affiliate || 'unknown',
    created_at: Date.now()
  };
  // avoid duplicate
  if (!db.findConversionByOrder(conversion.order_id)) {
    db.insertConversion(conversion);
    console.log('Saved conversion', conversion.order_id, conversion.affiliate);
  } else {
    console.log('Conversion already exists for', conversion.order_id);
  }

  // Optionally: notify affiliate network here (API call)

  res.status(200).send('ok');
});

// Import endpoint (protected by simple token header in sample)
app.post('/import/affiliates', async (req, res) => {
  const secret = req.get('x-import-secret') || '';
  if (process.env.IMPORT_SECRET && secret !== process.env.IMPORT_SECRET) return res.status(403).send('forbidden');
  try {
    const items = await affiliateService.importFromNetworks();
    console.log('Imported items', items.length);
    res.status(200).send({ imported: items.length });
  } catch (err) {
    console.error(err);
    res.status(500).send('err');
  }
});

app.get('/', (req, res) => res.send('Affiliate & Dropship App running'));

const port = process.env.PORT || 8080;
app.listen(port, () => console.log('Listening on', port));
