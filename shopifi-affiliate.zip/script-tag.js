// script-tag.js — include this snippet in the storefront or add as a ScriptTag
(function(){
  function getParam(name) {
    const url = new URL(window.location.href);
    return url.searchParams.get(name);
  }
  const aff = getParam('ref') || getParam('aff') || getParam('utm_aff');
  if (!aff) return;
  const expiry = new Date(Date.now() + 30*24*60*60*1000).toUTCString();
  document.cookie = 'affiliate=' + encodeURIComponent(aff) + '; expires=' + expiry + '; path=/; SameSite=Lax';
  // send beacon
  const payload = JSON.stringify({token: aff, url: location.href, ts: Date.now()});
  try { navigator.sendBeacon('/affiliate/click', payload); } catch(e){
    fetch('/affiliate/click', {method: 'POST', headers:{'Content-Type':'application/json'}, body: payload}).catch(()=>{});
  }
})();
