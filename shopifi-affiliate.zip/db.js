// db.js
const fs = require('fs');
const path = require('path');
const USE_SQLITE = process.env.USE_SQLITE !== 'false';

if (USE_SQLITE) {
  const Database = require('better-sqlite3');
  const dbFile = process.env.DATABASE_FILE || './data/sqlite.db';
  const dir = path.dirname(dbFile);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const db = new Database(dbFile);

  db.prepare(`CREATE TABLE IF NOT EXISTS clicks (
    id TEXT PRIMARY KEY,
    affiliate TEXT,
    url TEXT,
    ip TEXT,
    user_agent TEXT,
    created_at INTEGER
  )`).run();

  db.prepare(`CREATE TABLE IF NOT EXISTS conversions (
    id TEXT PRIMARY KEY,
    order_id TEXT,
    email TEXT,
    amount REAL,
    affiliate TEXT,
    created_at INTEGER
  )`).run();

  module.exports = {
    insertClick: (row) => db.prepare("INSERT INTO clicks (id, affiliate, url, ip, user_agent, created_at) VALUES (?, ?, ?, ?, ?, ?)").run(row.id, row.affiliate, row.url, row.ip, row.user_agent, row.created_at),
    findClickByAffiliate: (affiliate) => db.prepare("SELECT * FROM clicks WHERE affiliate = ? ORDER BY created_at DESC LIMIT 1").get(affiliate),
    insertConversion: (row) => db.prepare("INSERT INTO conversions (id, order_id, email, amount, affiliate, created_at) VALUES (?, ?, ?, ?, ?, ?)").run(row.id, row.order_id, row.email, row.amount, row.affiliate, row.created_at),
    findConversionByOrder: (orderId) => db.prepare("SELECT * FROM conversions WHERE order_id = ?").get(orderId),
  };
} else {
  throw new Error('Postgres mode not implemented; set USE_SQLITE=true for now.');
}
