# Shopify Affiliate & Dropshipping App (Node.js) - Cloud Run ready

This is a production-ready ZIP prepared for Cloud Run deployment. It includes a Dockerfile, app code, and CI workflow that produces a zip artifact.

Quick steps:
1. Edit `sample.env` -> save as `.env` with real secrets.
2. Build & deploy to Cloud Run (see Dockerfile).
3. Configure Shopify store webhooks to point to `/webhooks/orders/paid` and set the webhook secret in `.env`.
