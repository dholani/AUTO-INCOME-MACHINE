// affiliateService.js
const fetch = require('node-fetch');

module.exports = {
  // placeholder to fetch conversions from external networks
  async importFromNetworks() {
    const results = [];
    // TODO: implement real API calls for Admitad / Travelpayouts / Impact using their docs and API keys.
    return results;
  }
};
